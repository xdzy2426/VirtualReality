using UnityEngine;
using System.Collections;
public class ZTest : MonoBehaviour {
    public Renderer rd;
    public Material[] mats;
    public string[] labels;
    public Rect rect, tip;
    public int n;
	// Use this for initialization
	void Start () {
        rd=this.GetComponent<MeshRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
        rd.material = mats[n];
	}
    void OnGUI()
    {
        n = (int)GUI.HorizontalSlider(rect, n, 0, 6);
        GUI.Label(tip,"Current ZTest "+labels[n]);
    }
}
