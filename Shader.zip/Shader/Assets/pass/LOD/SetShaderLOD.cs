﻿using UnityEngine;
using System.Collections;

public class SetShaderLOD : MonoBehaviour {
    public Shader myShader;
    private float val = 6;
    void Update()
    {
        myShader.maximumLOD = (int)val * 100;
    }
    void OnGUI()
    {
        val = (int)GUI.HorizontalSlider(new Rect(250,125,300,30), val, 3, 6);
        GUI.Label(new Rect(333, 100, 170, 30), "Current LOD is: " + val * 100);
    }
}
